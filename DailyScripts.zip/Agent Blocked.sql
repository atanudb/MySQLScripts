AGENT BLOCKED or BounceCTR mismatch

On Client
cd /u01/app/oracle/agent13cR4/agent_13.4.0.0.0/bin/emctl
./emctl stop agent && ./emctl clearstate agent && ./emctl start agent && ./emctl status agent
If agent shows blocked or needs synch, do these -

./emctl stop agent
./emctl secure agent (password: Oracle13c)
./emctl start agent
./emctl upload agent (will still show an error)

Log into OEM13c portal
Click on Targets, All Targets. In the search menu, type in the name of the host that is experiencing the issue.  All targets that are part of that host will come up.  Notice the one that says “Agent”.  Click on it and it will bring you to the Agent console.
Below the name of the host target name on the upper left, you will notice it says, “Agent”  Click on this and then in the drop down menu, click on “Resyncronization”.
Follow through the defaults and click then click on the job that is submitted to perform the resync.  You can monitor it till it’s complete, (sometimes it can take up to a 1/2 hour to clear out all the issues.
Once it says “Succeeded”, then you can log in and successfully upload, as well as the status should be green for all targets connected to this agent.


BounceCTR mismatch

On Client
cd /u01/app/oracle/agent13cR4/agent_inst/sysman/emd/
[root@spt1pidb05 emd]# grep bounceCtr agntstmp.txt
bounceCtr=7

On cpr1oedb01
ALTER SESSION SET CONTAINER=CPROMA1;
SQL> select BOUNCE_CTR from sysman.MGMT_EMD_PING where TARGET_GUID=(select target_guid from sysman.mgmt_targets where target_name ='spt1pidb05.bolt.admiral.uk:1832');

BOUNCE_CTR
----------
         7

 On Client
 [oracle@spt1pidb05 ~]$ . oraenv
ORACLE_SID = [oracle] ? SPT1CDA1
The Oracle base remains unchanged with value /u01/app/oracle
[oracle@spt1pidb05 ~]$ cd /u01/app/oracle/agent13cR4/agent_13.4.0.0.0/bin/
[oracle@spt1pidb05 bin]$ ./emctl stop agent
Oracle Enterprise Manager Cloud Control 13c Release 4
Copyright (c) 1996, 2020 Oracle Corporation.  All rights reserved.
Stopping agent ... stopped.
[oracle@spt1pidb05 bin]$ pwd
/u01/app/oracle/agent13cR4/agent_13.4.0.0.0/bin
[oracle@spt1pidb05 bin]$ cd /u01/app/oracle/agent13cR4/agent_inst/sysman/emd/
[oracle@spt1pidb05 emd]$ grep bounceCtr agntstmp.txt
bounceCtr=7
[oracle@spt1pidb05 emd]$ cp agntstmp.txt agntstmp.old
[oracle@spt1pidb05 emd]$ vi agntstmp.txt

Edit the value of bouncectr to 1 less than counter value of cpr1oedb01.

[oracle@spt1pidb05 emd]$ cd /u01/app/oracle/agent13cR4/agent_13.4.0.0.0/bin/
[oracle@spt1pidb05 bin]$ ./emctl start agent

Check status of agent. It takes some time for the status to be green on OEM, so have patience.