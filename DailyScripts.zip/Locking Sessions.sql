@?/rdbms/admin/utllockt


SELECT 'alter system kill session '''||s.SID||',' ||s.SERIAL#||',@'||s.inst_id||''' immediate;' FROM   gv$session s, gv$session_wait w where s.status != 'ACTIVE' and s.machine like 'cpr1pcdw%' and s.sid=w.sid and s.inst_id=w.inst_id and w.EVENT = 'SQL*Net message from client' and s.seconds_in_wait > 10 order by s.inst_id,s.sid;

substitute cpr1pcon%, cpr1pcdw%

alter system kill session '821,23107,@2' immediate;
