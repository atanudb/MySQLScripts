purge_bc_mh.sh
-------------------------------------------------------------------------------
#!/bin/bash
export PATH=$PATH:/usr/local/bin/
export ORACLE_SID=CPR1SRA1
export ORACLE_BASE=/u01/app/oracle
export ORAENV_ASK=NO
. oraenv

DT=$(date "+%Y%m%d%H%M%S")
echo $DT
sqlplus / as sysdba <<EOF
set serveroutput on size unlimited
set time on timing on trimspool on

spool /home/oracle/logs/purge_bc_mh_$DT.log
@/home/oracle/scripts/space.sql
@/home/oracle/scripts/bc_partmh.sql
exec pkg_drop_partition.drop_bc_partition(p_days_to_keep=>15)
@/home/oracle/scripts/bc_mhidx.sql
@/home/oracle/scripts/bc_partmh.sql
@/home/oracle/scripts/space.sql
spool off
EOF




purge_pc_mh.sh
------------------------------------------------------------------------------
#!/bin/bash
export PATH=$PATH:/usr/local/bin/
export ORACLE_SID=CPR1SRA1
export ORACLE_BASE=/u01/app/oracle
export ORAENV_ASK=NO
. oraenv

DT=$(date "+%Y%m%d%H%M%S")
echo $DT
sqlplus / as sysdba <<EOF
set serveroutput on size unlimited
set time on timing on trimspool on

spool /home/oracle/logs/purge_pc_mh_$DT.log
@/home/oracle/scripts/space.sql
@/home/oracle/scripts/pc_partmh.sql
exec pkg_drop_partition.drop_pcsor_partition(p_days_to_keep=>15, p_arc=>'Y')
@/home/oracle/scripts/pc_mhidx.sql
@/home/oracle/scripts/pc_partmh.sql
@/home/oracle/scripts/space.sql
spool off
EOF



space.sql
-------------------------------------------------------------------------------
set lines 160 pages 999 pause off echo off feedb on

column tablespace_name        head 'Tablespace|Name'       format 9,999,990.00
column avail_size             head 'Available|Size (MB)'   format 9,999,990.00
column alloc_size             head 'Allocated|Size (MB)'   format 9,999,990.00
column space_used             head 'Space Used (MB)'       format 9,999,990.00
column avail_space_used_pct   head 'Available|Used (%)'    format 990.0
column alloc_space_used_pct   head 'Allocated|Used (%)'    format 990.0
column avail_free_space       head 'Available|Free (MB)'   format 9,999,999.00
column alloc_free_space       head 'Allocated|Free (MB)'   format 9,999,999.00
column count_df               head 'Datafiles'             format 999

select
   a.tablespace_name,
   a.bytes_alloc/(1024*1024) avail_size,
   a.physical_bytes/(1024*1024) alloc_size,
   nvl(b.tot_used,0)/(1024*1024) space_used,
   (nvl(b.tot_used,0)/a.bytes_alloc)*100 avail_space_used_pct,
   (nvl(b.tot_used,0)/a.physical_bytes)*100 alloc_space_used_pct,
   a.bytes_alloc/(1024*1024) - nvl(b.tot_used,0)/(1024*1024)  avail_free_space,
   a.physical_bytes/(1024*1024) - nvl(b.tot_used,0)/(1024*1024)  alloc_free_space,
   count_df
from
   (select
      tablespace_name,
      sum(bytes) physical_bytes,
      sum(decode(autoextensible,'NO',bytes,'YES',maxbytes)) bytes_alloc,
      count(*) count_df
    from
      dba_data_files
    group by
      tablespace_name ) a,
   (select
      tablespace_name,
      sum(bytes) tot_used
    from
      dba_segments
    group by
      tablespace_name ) b
where
   a.tablespace_name = b.tablespace_name (+)
and
   a.tablespace_name not in
   (select distinct
       tablespace_name
    from
       dba_temp_files)
and
   a.tablespace_name not like 'UNDO%'
order by 1
/
--------------------------------------------------------------------


pc_partmh.sql
--------------------------------------------------------------------
col partition_name for a30
col high_value for a40
select partition_name, high_value, partition_position, TRUNC(SYSDATE)-TRUNC(pkg_drop_partition.get_date(table_owner, table_name, partition_name)) keepdays
from dba_tab_partitions where table_name='PC_MESSAGEHISTORY' order by partition_position;



pc_mhidx.sql
--------------------------------------------------------------------
col index_name for a30
select index_name, status, orphaned_entries from dba_indexes where table_name='PC_MESSAGEHISTORY'
/


bc_partmh.sql
--------------------------------------------------------------------
col partition_name for a30
col high_value for a40
select partition_name, high_value, partition_position, TRUNC(SYSDATE)-TRUNC(pkg_drop_partition.get_date(table_owner, table_name, partition_name)) keepdays
from dba_tab_partitions where table_name='BC_MESSAGEHISTORY' order by partition_position;


bc_mhidx.sql
--------------------------------------------------------------------
col index_name for a30
select index_name, status, orphaned_entries from dba_indexes where table_name='BC_MESSAGEHISTORY'
/



drp.pks 
---------------
create or replace PACKAGE BODY pkg_drop_partition AS

PROCEDURE print(p_msg IN VARCHAR2) IS
BEGIN
        dbms_output.put_line(TO_CHAR(sysdate, 'DD/MM/YYYY HH24:MI.SS')||' : '||p_msg);
END print;

FUNCTION get_date (p_table_owner IN VARCHAR2, p_table_name IN VARCHAR2, p_partition_name IN VARCHAR2) RETURN DATE IS
        v_high_value    VARCHAR2(1024);
        val_date        DATE;
BEGIN
        select high_value into v_high_value from dba_tab_partitions
        where table_owner = UPPER(p_table_owner)
        and table_name = upper(p_table_name)
        and partition_name = upper(p_partition_name);
        execute immediate 'select ' || v_high_value || ' from dual' into val_date;
        RETURN val_date;
END get_date;

FUNCTION get_keep_days (p_table_owner IN VARCHAR2, p_table_name IN VARCHAR2) RETURN NUMBER IS
        v_keep_days NUMBER;
BEGIN
-- return the keep days required for c_part_catchup_count partitions (catch-up mode) or a minimum of c_min_days_to_keep keep days (steady-state mode)
        SELECT TRUNC(SYSDATE-MAX(dt)) INTO v_keep_days
        FROM (
                SELECT table_owner, table_name, partition_name, get_date(table_owner, table_name, partition_name) dt,
                        ROW_NUMBER() OVER (ORDER BY get_date(table_owner, table_name, partition_name))  row_number
                FROM   dba_tab_partitions
                WHERE table_owner = UPPER(p_table_owner) AND table_name = UPPER(p_table_name) AND partition_name != 'P0'
        ) WHERE row_number < c_part_catchup_count;

        print('calculated keep days = ' || v_keep_days);
        print('min keep days = ' || c_min_days_to_keep);
        IF NVL(v_keep_days, 0) < c_min_days_to_keep THEN
                v_keep_days := c_min_days_to_keep;
        END IF;
        RETURN v_keep_days;
END get_keep_days;

PROCEDURE show_undo_redo IS
        v_redo NUMBER;
        v_undo NUMBER;
BEGIN
        SELECT value INTO v_redo FROM  v$mystat natural join v$statname where name = 'redo size';
        SELECT value INTO v_undo FROM  v$mystat natural join v$statname where name = 'undo change vector size';
        print('Redo: '||v_redo||'    Undo: '||v_undo);
END show_undo_redo;

--
-- Actual main drop partition for PCSOR.PC_MESSAGEHISTORY...
--
PROCEDURE drop_pcsor_partition (p_days_to_keep IN NUMBER DEFAULT get_keep_days('PCSOR', 'PC_MESSAGEHISTORY'),
                                p_arc IN VARCHAR2 DEFAULT 'Y') IS
        e_last_part     EXCEPTION;
        v_sql           VARCHAR2(1000);
        v_rowcount      PLS_INTEGER;
        v_table_owner   VARCHAR2(30) := 'PCSOR';
        v_table_name    VARCHAR2(30) := 'PC_MESSAGEHISTORY';
        v_base_part     VARCHAR2(30) := 'P0';
        v_drop_count    PLS_INTEGER := 0;
        PRAGMA EXCEPTION_INIT(e_last_part, -14758);
BEGIN
        print('Running PCSOR drop partition...');
        print('table_owner = '||v_table_owner||'  table_name = '||v_table_name||'  days_to_keep = ' || p_days_to_keep);

        FOR ut IN (
                SELECT table_owner, table_name, partition_name FROM dba_tab_partitions
                WHERE table_owner = UPPER(v_table_owner) AND UPPER(table_name) = v_table_name AND partition_name != UPPER(v_base_part)
                AND get_date(table_owner, table_name, partition_name) <= TRUNC(SYSDATE) - p_days_to_keep
                ORDER BY get_date(table_owner, table_name, partition_name))
        LOOP
        BEGIN
                print('Processing...'||ut.table_name||'('||ut.partition_name||')');
                show_undo_redo;
                v_sql := 'BEGIN select count(*) into :rowcnt from '||ut.table_owner||'.'||ut.table_name||
                                        ' PARTITION ('||ut.partition_name||'); END;';
                execute immediate v_sql USING OUT v_rowcount;
                print('rows in partition = '||v_rowcount);

                IF p_arc = 'Y' THEN
                        print('inserting Thunderhead error archive rows...');
                        v_sql := 'INSERT INTO mharc.pc_messagehistory_th_err SELECT * FROM '||ut.table_owner||'.'||ut.table_name||
                                        ' PARTITION ('||ut.partition_name||') WHERE destinationid = 22 AND status != 10';
                        print(v_sql);
                        execute immediate v_sql;
                        print('rows inserted = '||SQL%ROWCOUNT);
                        show_undo_redo;

                        print('inserting Non-Thunderhead archive rows...');
                        v_sql := 'INSERT INTO mharc.pc_messagehistory_arc SELECT * FROM '||ut.table_owner||'.'||ut.table_name||
                                        ' PARTITION ('||ut.partition_name||') WHERE destinationid != 22';
                        print(v_sql);
                        execute immediate v_sql;
                        print('rows inserted = '||SQL%ROWCOUNT);
                        show_undo_redo;
                END IF;

                v_sql := 'ALTER TABLE '||ut.table_owner||'.'||ut.table_name||' DROP PARTITION '||ut.partition_name||' UPDATE INDEXES';
                print(v_sql);
                execute immediate v_sql;
                show_undo_redo;
                v_drop_count := v_drop_count + 1;
        EXCEPTION
                WHEN e_last_part THEN
                BEGIN
                        print('last partition, cannot be dropped');
                        RAISE_APPLICATION_ERROR(-20000, 'Cannot drop last partition in table '||v_table_name);
                END;
                WHEN OTHERS THEN
                        RAISE_APPLICATION_ERROR(-20999, 'UHE: SQLCODE = '||SQLCODE);
        END;
        END LOOP;

        print('Partitions dropped = '||v_drop_count);
        IF v_drop_count > 0 THEN
                print('Global Index cleanup...');
                dbms_part.cleanup_gidx(v_table_owner, v_table_name);
                show_undo_redo;
        END IF;

        print('Finished...');
END drop_pcsor_partition;

--
-- Actual main drop partition for BC.BC_MESSAGEHISTORY...
--
PROCEDURE drop_bc_partition (p_days_to_keep IN NUMBER DEFAULT get_keep_days('BC', 'BC_MESSAGEHISTORY')) IS
        e_last_part     EXCEPTION;
        v_sql           VARCHAR2(1000);
        v_rowcount      PLS_INTEGER;
        v_table_owner   VARCHAR2(30) := 'BC';
        v_table_name    VARCHAR2(30) := 'BC_MESSAGEHISTORY';
        v_base_part     VARCHAR2(30) := 'P0';
        v_drop_count    PLS_INTEGER := 0;
        PRAGMA EXCEPTION_INIT(e_last_part, -14758);
BEGIN
        print('Running BC drop partition...');
        print('table_owner = '||v_table_owner||'  table_name = '||v_table_name||'  days_to_keep = ' || p_days_to_keep);

        FOR ut IN (
                SELECT table_owner, table_name, partition_name FROM dba_tab_partitions
                WHERE table_owner = UPPER(v_table_owner) AND table_name = UPPER(v_table_name) AND partition_name != UPPER(v_base_part)
                AND get_date(table_owner, table_name, partition_name) <= TRUNC(SYSDATE) - p_days_to_keep
                ORDER BY get_date(table_owner, table_name, partition_name))
        LOOP
        BEGIN
                print('Processing...'||ut.table_name||'('||ut.partition_name||')');
                show_undo_redo;

                v_sql := 'BEGIN select count(*) into :rowcnt from '||ut.table_owner||'.'||ut.table_name||
                                        ' PARTITION ('||ut.partition_name||'); END;';
                execute immediate v_sql USING OUT v_rowcount;
                print('rows in partition = '||v_rowcount);

                v_sql := 'ALTER TABLE '||ut.table_owner||'.'||ut.table_name||' DROP PARTITION '||ut.partition_name||' UPDATE INDEXES';
                print(v_sql);
                execute immediate v_sql;
                show_undo_redo;
                v_drop_count := v_drop_count + 1;
        EXCEPTION
                WHEN e_last_part THEN
                BEGIN
                        print('last partition, cannot be dropped');
                        RAISE_APPLICATION_ERROR(-20000, 'Cannot drop last partition in table '||v_table_name);
                END;
                WHEN OTHERS THEN
                        RAISE_APPLICATION_ERROR(-20999, 'UHE: SQLCODE = '||SQLCODE);
        END;
        END LOOP;

        print('Partitions dropped = '||v_drop_count);
        IF v_drop_count > 0 THEN
                print('Global Index cleanup...');
                dbms_part.cleanup_gidx(v_table_owner, v_table_name);
                show_undo_redo;
        END IF;

        print('Finished...');
END drop_bc_partition;

END pkg_drop_partition;
/