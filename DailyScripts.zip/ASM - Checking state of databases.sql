Checking state of databases

set environment to ASM

crsctl stat res -t




Example -

dbrac1(/u01/grid/product/12.1.0/bin)# ./crsctl stat res -t

CRS-4535: Cannot communicate with Cluster Ready Services
CRS-4000: Command Status failed, or completed with errors.

dbrac1(/u01/grid/product/12.1.0/bin)# ./crsctl check crs
CRS-4638: Oracle High Availability Services is online
CRS-4535 : Cannot communicate with Cluster Ready Services
CRS-4529 : Cluster Synchronization Services is online
CRS-4533: Event Manager is online

ps -fea |grep crsd.bin

dbrac1(/u01/grid/product/12.1.0/bin)# ./crsctl start res ora.crsd -init
CRS-2672: Attempting to start 'ora.crf' on 'dbrac1'
CRS-2672: Attempting to start 'ora.storage' on 'dbrac1'
CRS-2676: Start of 'ora.crf' on 'dbrac1' succeeded
CRS-2676: Start of 'ora.storage' on 'dbrac1' succeeded
CRS-2672: Attempting to start 'ora.crsd' on 'dbrac1'
CRS-2676: Start of 'ora.crsd' on 'dbrac1' succeeded

Recheck status of CRS -
./crsctl stat res -t

