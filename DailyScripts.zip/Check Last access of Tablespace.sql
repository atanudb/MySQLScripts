Check Last access of Tablespace
-----------------------------------------------------------------------------------------------

select  b.tablespace_name, to_date(max(a.last_ddl_time),'DD-MM-YYYY HH:MI:SS') LAST_DDL_TIME
from dba_objects a, dba_segments b
where a.owner=b.owner
and a.object_name=b.segment_name
group by b.tablespace_name;