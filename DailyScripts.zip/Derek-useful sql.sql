mkdir -p /home/oracle/rundeck_jobs

mkdir -p /home/oracle/logs


export SVNUSER=holderd2
svn export --force --username ${SVNUSER} http://celine.admiral.uk/svn/infrastructure/oracle/scripts/DBA_Admin/adrci_jobs.sh ${HOME}/rundeck_jobs/adrci_jobs.sh


chmod 750 /home/oracle/rundeck_jobs/adrci_jobs.sh


00 00 * * *  /home/oracle/rundeck_jobs/adrci_jobs.sh >  /home/oracle/logs/adrci.log 2>&1


cd $ORACLE_BASE/diag/rdbms/cp*/CP*/trace

adrci
show home
purge -age 14400 -type UTSCDMP

du -m /home/oracle | sort -n -k 1 | tail
du -m /u02/ | sort -n -k 1 | tail
du -m /u01/ | sort -n -k 1 | tail

cd $ORACLE_BASE/diag/rdbms/cpr*/CPR*/trace
/u01/app/oracle/diag/rdbms/cpr1sra/CPR1SRA1/trace

view alert*log

cd $ORACLE_BASE/diag/rdbms/spr*/SPR*/trace

select distinct(machine) from gv$session;

SELECT s.sid, s.serial#, s.username, s.osuser, p.spid, s.machine, p.terminal, s.program
FROM v$session s, v$process p
WHERE s.paddr = p.addr
and s.machine like 'spr1thba01.bolt.admiral.uk%';

cd /u01/app/oracle/agent/core/12.1.0.4.0/bin
./emctl stop agent && ./emctl clearstate agent && ./emctl start agent && ./emctl status agent


SELECT s.sid, s.serial#, s.username, s.osuser, p.spid, s.machine, p.terminal, s.program
FROM v$session s, v$process p
WHERE s.paddr = p.addr
and s.machine='cpp1apdb01.bolt.admiral.uk';


select distinct(machine) from gv$session;



find . -type f -newermt 2017-04-03 ! -newermt 2017-04-04


create profile NOEXP limit PASSWORD_LIFE_TIME unlimited;


asmcmd lsdsk -G DATA
#1486131400
asmcmd lsdsk -G FRA
#1486131422
asmcmd lsdsk -G CRS


asmca -silent -addDisk -diskGroupName DATA -disk '/dev/oracleasm/disksdq'




SELECT s.sid, s.serial#, s.username, s.osuser, p.spid, s.machine, p.terminal, s.program
FROM v$session s, v$process p
WHERE s.paddr = p.addr
and s.machine not like '%pr1%db%';





set linesize 132 tab off trimspool on
set pagesize 105
set pause off
set echo off
set feedb on

column "TOTAL ALLOC (MB)" format 9,999,990.00
column "TOTAL PHYS ALLOC (MB)" format 9,999,990.00
column "USED (MB)" format  9,999,990.00
column "FREE (MB)" format 9,999,990.00
column "% USED" format 990.00

select a.tablespace_name,
       a.bytes_alloc/(1024*1024) "TOTAL ALLOC (MB)",
       a.physical_bytes/(1024*1024) "TOTAL PHYS ALLOC (MB)",
       nvl(b.tot_used,0)/(1024*1024) "USED (MB)",
       (nvl(b.tot_used,0)/a.bytes_alloc)*100 "% USED"
from ( select tablespace_name,
       sum(bytes) physical_bytes,
       sum(decode(autoextensible,'NO',bytes,'YES',maxbytes)) bytes_alloc
       from dba_data_files
       group by tablespace_name ) a,
     ( select tablespace_name, sum(bytes) tot_used
       from dba_segments
       group by tablespace_name ) b
where a.tablespace_name = b.tablespace_name (+)
--and   (nvl(b.tot_used,0)/a.bytes_alloc)*100 > 10
and   a.tablespace_name not in (select distinct tablespace_name from dba_temp_files)
--and   a.tablespace_name not like 'UNDO%'
order by 1
--order by 5
/


SELECT FILE_NAME, bytes/1024/1024 maxmegs, autoextensible, maxbytes/1024/1024, file_id from dba_data_files where tablespace_name = '' ORDER BY FILE_ID;



thunderheady stuff:
SELECT * FROM DBA_2PC_PENDING;
SELECT * FROM DBA_2PC_NEIGHBORS;
select 'commit force '''||local_tran_id||''' ;' from dba_2pc_pending ;


select 'exec dbms_transaction.purge_lost_db_entry('''||local_tran_id||''' )' , 'commit;' from
dba_2pc_pending;


export SVNUSER=holderd2
svn export --force --username ${SVNUSER} http://svn.bolt.admiral.uk/ADM-Infrastructure/trunk/scripts/development/default/oracle/audit-service/*.sql ./


SELECT name, scn, time, database_incarnation#, guarantee_flashback_database, storage_size FROM v$restore_point;

SELECT * FROM V$RECOVERY_FILE_DEST;

SELECT * FROM V$FLASH_RECOVERY_AREA_USAGE;

--recyclebin sizeage
select owner,sum(space)* 8 / 1024/1024 "Size in GB" from dba_recyclebin group by owner order by sum(space) ;




select GROUP_NUMBER DG#, name, ALLOCATION_UNIT_SIZE AU_SZ, STATE,
 TYPE, TOTAL_MB, FREE_MB, OFFLINE_DISKS from v$asm_diskgroup;


RUN { EXECUTE GLOBAL SCRIPT backup_level_0_prod; }

RUN { EXECUTE GLOBAL SCRIPT backup_level_1_prod; }

RUN { EXECUTE GLOBAL SCRIPT backup_comp_arch_prod; }

#RUN { EXECUTE GLOBAL SCRIPT spr1_del_archivelogs; }



### stats info
alter session set nls_date_format = 'DD-MON-YYYY HH24:MI:SS';
select * from dba_tab_stats where table_name ='';

