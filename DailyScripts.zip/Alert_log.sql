
To check for the location of the alert log - Use -
----------------------------------------------------------------------------------
select * from v$diag_info;


To read the alert log, from the Linux prompt, run 
----------------------------------------------------------------------------------
view /u01/app/oracle/diag/rdbms/ctr3gw1/CTR3GW1/trace/alert_CTR3GW1.log G

/u01/app/oracle/diag/rdbms/rbdb1/RBDB1/trace