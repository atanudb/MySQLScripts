select * from v$flash_recovery_area_usage
/

