select SID, Serial#, username, status, schemaname, logon_time from v$session where status='Active' and username is not null;


set pages 300 lines 500
col username format A10
col osuser format a15
col machine format a35
col schemaname format a10
select SID, Serial#, username, machine, osuser, program, status, schemaname, logon_time from v$session order by status;


Alternate way -
----------------------------

select machine, count(*) from gv$session group by machine order by machine;




---- PURGE RECYCLE BIN
purge dba_recyclebin;

