SET PAGES 10000 LINES 200 TRIMS ON

COL today NEW_VALUE today
SELECT TO_CHAR(sysdate, 'yyyymmddhh24miss') today FROM DUAL;

COL dbname NEW_VALUE dbname
SELECT name dbname FROM v$database;

COL dir_name NOPRINT
COL file_name FORMAT A80
COL file_type FORMAT A7
COL mbytes FORMAT 999,999,990
COL maxmbytes FORMAT 999,999,990

BREAK ON dir_name SKIP 1 ON report
COMPUTE SUM OF mbytes maxmbytes ON dir_name report

SPOOL dbfiles_&dbname._&today

SELECT SUBSTR(file_name, 1, INSTR(file_name, '/', -1) - 1) dir_name
        , file_name, file_type, bytes/1024/1024 mbytes, maxbytes/1024/1024 maxmbytes
FROM (
        SELECT 'DATA' file_type, file_name, bytes, GREATEST(bytes, maxbytes) maxbytes
        FROM dba_data_files
        UNION ALL
        SELECT 'TEMP', file_name, bytes, GREATEST(bytes, maxbytes)
       FROM dba_temp_files
        UNION ALL
        SELECT 'CONTROL', name, block_size * file_size_blks, block_size * file_size_blks
        FROM v$controlfile
        UNION ALL
        SELECT 'LOGFILE', lf.member, bytes, bytes
        FROM v$log l
        JOIN v$logfile lf
        ON l.group# = lf.group#
)
ORDER BY 1;
