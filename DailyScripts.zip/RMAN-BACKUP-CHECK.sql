All Backup details 
*******************
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';

column start_time format 9999.99
column end_time format 9999.99
column output_device_type format a10
column input_type format a20
column status format a40
column time_taken_display format a10
column input_bytes_display format a10
column output_bytes_display format a30
set linesize 300
set pagesize 1000
select SESSION_RECID,session_stamp,start_time,end_time,output_device_type,input_type,status,time_taken_display,input_bytes_display,output_bytes_display from V$RMAN_BACKUP_JOB_DETAILS  order by start_time  asc;



Full Level 1 / Level 0 details 
******************************
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
set lines 300
set pages 1000
col STATUS format a9
col "Level" form 0
col "Input GB" form 99990.99
col "Output GB" form 99990.99
col hrs format 999.99
col status format a20
col START_TIME format 999.99
col END_TIME format 999.99
select distinct rb.SESSION_KEY, rb.INPUT_TYPE, bs.incremental_level "Level", rb.STATUS,
  to_char(rb.START_TIME,'dd/mm/yy hh24:mi') start_time,
  to_char(rb.END_TIME,'dd/mm/yy hh24:mi') end_time,
  round(rb.INPUT_BYTES/1024/1024/1024,2) "Input GB",
  round(rb.OUTPUT_BYTES/1024/1024/1024,2) "Output GB",
  rb.elapsed_seconds/3600 hrs 
from V$RMAN_BACKUP_JOB_DETAILS rb, v$backup_set_details bs
where rb.START_TIME > trunc(SYSDATE) -360 and 
   bs.session_recid = rb.session_recid
  and bs.session_key = rb.session_key
  and bs.session_stamp = rb.session_stamp 
  and bs.incremental_level is not null
order by rb.session_key desc;


estimate completion time
************************

col dbsize_mbytes      for 99,999,990.00 justify right head "DBSIZE_MB"
col input_mbytes       for 99,999,990.00 justify right head "READ_MB"
col output_mbytes      for 99,999,990.00 justify right head "WRITTEN_MB"
col output_device_type for a10           justify left head "DEVICE"
col complete           for 990.00        justify right head "COMPLETE %" 
col compression        for 990.00        justify right head "COMPRESS|% ORIG"
col est_complete       for a20           head "ESTIMATED COMPLETION"
col recid              for 9999999       head "ID"
col event for a40
col client_info for a30

select client_info
     , event 
  from v$session 
 where event like 'Backup%'
 order by client_info;

select recid
     , output_device_type
     , dbsize_mbytes
     , input_bytes/1024/1024 input_mbytes
     , output_bytes/1024/1024 output_mbytes
     , (output_bytes/input_bytes*100) compression
     , (mbytes_processed/dbsize_mbytes*100) complete
     , to_char(start_time + (sysdate-start_time)/(mbytes_processed/dbsize_mbytes),'DD-MON-YYYY HH24:MI:SS') est_complete
  from v$rman_status rs
     , (select sum(bytes)/1024/1024 dbsize_mbytes from v$datafile) 
 where status='RUNNING'
   and output_device_type is not null
/

*******************

alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
select sl.sid, sl.opname,
       to_char(100*(sofar/totalwork), '990.9')||'%' pct_done,
       sysdate+(TIME_REMAINING/60/60/24) done_by
  from v$session_longops sl, v$session s
 where sl.sid = s.sid
   and sl.serial# = s.serial#
   and sl.sid in (select sid from v$session where module like 'backup%' or module like 'restore%' or module like 'rman%')
   and sofar != totalwork
        and totalwork > 0
/

estimate rman percentage complete
*********************************

SELECT SID, SERIAL#, CONTEXT, SOFAR, TOTALWORK,
       ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE"
FROM   V$SESSION_LONGOPS
WHERE  OPNAME LIKE 'RMAN%'
AND    OPNAME NOT LIKE '%aggregate%'
AND    TOTALWORK != 0
AND    SOFAR <> TOTALWORK;


duration of previous rman jobs
******************************
col OPNAME format a70
select OPNAME,SOFAR/TOTALWORK*100 PCT, trunc(TIME_REMAINING/60) MIN_RESTANTES,
trunc(ELAPSED_SECONDS/60) MIN_ATEAGORA from v$session_longops where TOTALWORK>0 and OPNAME like '%RMAN%';

progress in size
****************

select to_char(start_time, 'dd-mon-yyyy@hh24:mi:ss') "Date", 
status, 
operation,
mbytes_processed
from v$rman_status vs
where start_time >  sysdate -1
order by start_time
/


--
set lines 300
col MESSAGE format a60
set pages 99
SELECT SID, SERIAL#, MESSAGE, CONTEXT, SOFAR, TOTALWORK, ROUND(SOFAR/TOTALWORK*100,2) "%_COMPLETE" FROM V$SESSION_LONGOPS
WHERE OPNAME LIKE 'RMAN%' AND OPNAME NOT LIKE '%aggregate%' AND TOTALWORK != 0 AND SOFAR <> TOTALWORK;


--
run {
set until time "to_date('15-FEB-2018 15:30:00','DD-MON-YYYY HH24:MI:SS')";
restore database;
recover database;
alter database open resetlogs;
}