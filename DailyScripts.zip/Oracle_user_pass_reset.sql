--Oracle user expired pass word reset--
=======================================

Look at account details in DBA_USERS:

--sqlplus formatting
set line 132 pages 500

select username, profile, account_status from dba_users where account_status like '%EXPIRED%' order by username;

--we see user is expired called GWEXTERNAL
--so lets give it the correct user profile

alter user GWEXTERNAL profile NOEXP;

--we also need to reset the passowrd - but we don't know it so how do we find it?
--we use dbms_metadata.get_ddl eg:

--set long
SET LONG 1000000000

select dbms_metadata.get_ddl('USER', 'GWEXTERNAL') from DUAL;

--This gives us the create user sql, we just want part of that to reset the password using alter user sql

return is:

  CREATE USER "GWEXTERNAL" IDENTIFIED BY VALUES 'S:3A2446C4E97EC5835FB439056A7F
0C4F04688BEA8B74D8677ED3BF907F56;H:28B658F316DBE79674740CD5A39F43FF;T:39E7D176BB
159ECEBE0B77C660AB7EA1D139A672EED725F91A01A40F33B9D2CAE48A21B0ADC0B075F52AB16218
30A9DE2C7DDCEA7F1737C5DD38785CB36F0FB23A6010D094FE5231BD77F6D095DAC238;4595242FF
82E98BB'
      DEFAULT TABLESPACE "GWEXTERNAL"
      TEMPORARY TABLESPACE "TEMP"
      PROFILE "NOEXP"
      PASSWORD EXPIRE


--we want:
USER "GWEXTERNAL" IDENTIFIED BY VALUES 'S:3A2446C4E97EC5835FB439056A7F
0C4F04688BEA8B74D867:28B658F316DBE79674740CD5A39F43FF;T:39E7D176BB
159ECEBE0B77C660AB7EA1D139A672EED725F91A01A40F33B9D2CAE48A21B0ADC0B075F52AB16218
30A9DE2C7DDCEA7F1737C5DD38785CB36F0FB23A6010D094FE5231BD77F6D095DAC238;4595242FF
82E98BB'

--we have to make the hash all one line!

alter USER "GWEXTERNAL" IDENTIFIED BY VALUES 
'S:3A2446C4E97EC5835FB439056A7F0C4F04688BEA8B74D8677ED3BF907F56;H:28B658F316DBE79674740CD5A39F43FF;T:39E7D176BB159ECEBE0B77C660AB7EA1D139A672EED725F91A01A40F33B9D2CAE48A21B0ADC0B075F52AB1621830A9DE2C7DDCEA7F1737C5DD38785CB36F0FB23A6010D094FE5231BD77F6D095DAC238;4595242FF82E98BB';

eg of execution:
SQL> alter USER "GWEXTERNAL" IDENTIFIED BY VALUES
  2  'S:3A2446C4E979056A7F0C4F04688BEA8B74D8677ED3BF907F56;H:28B658F316DBE79674740CD5A39F43FF;T:39E7D176BB159ECEBE0B77C660AB7075F52AB1621830A9DE2C7DDCEA7F1737C5DD38785CB36F0FB23A6010D094FE5231BD77F6D095DAC238;4595242FF82E98BB';

User altered.

--now account should be back open and with original password:

SQL> select username, profile, account_status, created from dba_users where username ='GWEXTERNAL';

USERNAME
--------------------------------------------------------------------------------------------------------------------------------
PROFILE
--------------------------------------------------------------------------------------------------------------------------------
ACCOUNT_STATUS                   CREATED
-------------------------------- ---------
GWEXTERNAL
NOEXP
OPEN                             10-DEC-18


--- Unlock user
alter user <usernmae> account unlock;