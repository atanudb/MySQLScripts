col rnk                 for 99 heading '#'
col segment_name        for a30 head 'Segment Name'
col num_rows            for 99999999999 head 'Rows'
col last_analyzed       head 'Last Analyzed'
col timestamp           head 'Timestamp'
col gb                  for 9999.9
col ins                 for 999999999 head 'Inserts'
col del                 for 999999999 head 'Deletes'
col upd                 for 999999999 head 'Updates'
col daily_chg           for 9999999 head 'Daily|Additions'
col daily_growth        for 9999999 head 'Daily|Updates'
col pct_total           for 999.9 head '% Tot'

set pages 9999 lines 160
break on report
compute sum of gb on report
compute sum of pct_total on report

set term on feed off ver off
alter session set nls_date_format='DD-MON-YYYY HH24:MI.SS';

column 1 new_value 1 noprint
column 2 new_value 2 noprint
select '' "1" from dual where rownum = 0;
define param = &1 "BC_OP"
select '' "2" from dual where rownum = 0;
define param2 = &2 "20"

ttitle "&param Object Size (Top &param2)"

select  rank() over (order by bytes desc) rnk,
        seg.segment_name,
        TRUNC(bytes/1024/1024/1024, 1) GB,
        ROUND(100*(bytes / SUM(bytes) OVER ()), 2) pct_total,
        tab.num_rows, tmod.ins, tmod.del, tmod.upd, tab.last_analyzed, tmod.timestamp,
        trunc((tmod.ins - tmod.del) / (tmod.timestamp - tab.last_analyzed)) daily_growth,
        tmod.upd  / (tmod.timestamp - tab.last_analyzed) daily_chg
from    dba_segments seg        inner join dba_tables tab on (seg.segment_name = tab.table_name and seg.owner = tab.owner)
                inner join (    SELECT table_name, table_owner, timestamp, sum(inserts) ins, sum(deletes) del, sum(updates) upd
                                FROM dba_tab_modifications group by table_owner, table_name, timestamp) tmod
                                         on (tab.table_name = tmod.table_name and tab.owner = tmod.table_owner)
where   seg.tablespace_name='&param' AND tab.tablespace_name = '&param' and seg.segment_type = 'TABLE'
order by bytes desc fetch first &param2 rows only
/

undef 1

