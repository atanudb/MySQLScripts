Check Database Backups
*************************
archive log list


All Backup details 
*******************
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';

column start_time format 9999.99
column end_time format 9999.99
column output_device_type format a10
column input_type format a20
column status format a40
column time_taken_display format a10
column input_bytes_display format a10
column output_bytes_display format a30
set linesize 300
set pagesize 1000
select start_time,end_time,output_device_type,input_type,status,time_taken_display,input_bytes_display,output_bytes_display from V$RMAN_BACKUP_JOB_DETAILS  order by start_time  asc;


Alternative Script 
*******************************
Full Level 1 / Level 0 details 
******************************
alter session set nls_date_format='DD-MON-YYYY HH24:MI:SS';
set lines 300
set pages 1000
col STATUS format a9
col "Level" form 0
col "Input GB" form 99990.99
col "Output GB" form 99990.99
col hrs format 999.99
col status format a20
col START_TIME format 999.99
col END_TIME format 999.99
select distinct rb.SESSION_KEY, rb.INPUT_TYPE, bs.incremental_level "Level", rb.STATUS,
  to_char(rb.START_TIME,'dd/mm/yy hh24:mi') start_time,
  to_char(rb.END_TIME,'dd/mm/yy hh24:mi') end_time,
  round(rb.INPUT_BYTES/1024/1024/1024,2) "Input GB",
  round(rb.OUTPUT_BYTES/1024/1024/1024,2) "Output GB",
  rb.elapsed_seconds/3600 hrs 
from V$RMAN_BACKUP_JOB_DETAILS rb, v$backup_set_details bs
where rb.START_TIME > trunc(SYSDATE) -360 and 
   bs.session_recid = rb.session_recid
  and bs.session_key = rb.session_key
  and bs.session_stamp = rb.session_stamp 
  and bs.incremental_level is not null
order by rb.session_key desc;


Check RMAN settings
***************************************

history | grep -i "rman"
connect to RMAN (example - rman target / catalog rmancat/rmancat1@rmancat ) (rman target / catalog rmancat/rmancat1@rmancat)
RMAN> show all; 
RMAN> list backup summary;
