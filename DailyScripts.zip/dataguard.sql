
SET SID to Database name
dgmgrl /
DGMGRL>show configuration
					example -
					[oracle@spp1gwdb01 ~]$ dgmgrl /
					DGMGRL for Linux: Version 12.1.0.2.0 - 64bit Production

					Copyright (c) 2000, 2013, Oracle. All rights reserved.

					Welcome to DGMGRL, type "help" for information.
					Connected as SYSDG.
					DGMGRL> show configuration;

					Configuration - DGConf01

  					Protection Mode: MaxPerformance
  					Members:
  					CPP1SRA - Primary database
    				SPP1SRB - Physical standby database

					Fast-Start Failover: DISABLED

					Configuration Status:
					SUCCESS   (status updated 57 seconds ago)

DGMGRL> edit database 'DBNAME' set state='TRANSPORT-OFF';

DGMGRL>  EDIT DATABASE 'DBNAME_SB' SET STATE='APPLY-OFF';  

DGMGRL> show database verbose 'DBNAME'
Ensure Intended state is "Transport-OFF"
