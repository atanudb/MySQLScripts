Check Disk Allocation details - Log in as SYSASM to +ASM
=========================================================================

set lines 200
set underline off
col "ASM GROUP," form a10
col "Avail GB," form a10
col "Used GB," form a10
col "% Full" form i99
--break on "ASM GROUP,"
clear break
COMPUTE SUM Label "Total GB" OF "TOTAL_MB" ON Group
select g.NAME||',' "ASM GROUP,", substr(path,1,30)||',' "DISK," , d.TOTAL_MB/1024||',' "Avail GB,", round(d.TOTAL_MB/1024-d.FREE_MB/1024,0)||',' "Used GB,", 
100*round((d.TOTAL_MB-d.FREE_MB)/d.TOTAL_MB,2) "% Full"
from  V$ASM_DISKGROUP g, v$asm_disk d
where g.GROUP_NUMBER=d.GROUP_NUMBER order by 1 ;
