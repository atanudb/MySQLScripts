col partition_name for a30
col high_value for a55
set pages 9999
set lines 120
select partition_name, high_value from dba_tab_partitions where table_name='PC_MESSAGEHISTORY' and table_owner='PCSOR'
order by partition_position
/

