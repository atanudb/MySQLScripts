Fast Recovery Area Space Usage

SELECT * FROM V$RECOVERY_FILE_DEST;

SELECT * FROM V$RECOVERY_AREA_USAGE;


SQL> alter system set db_recovery_file_dest_size=20g scope=both;
