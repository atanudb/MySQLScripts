SELECT name, VALUE
  FROM v$parameter
 WHERE name = 'cluster_database';
