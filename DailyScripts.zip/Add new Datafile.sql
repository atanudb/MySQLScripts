alter tablespace BC_INDEX  add datafile '+DATA' size 32767M AUTOEXTEND ON  NEXT 1G maxsize  32767M;
alter tablespace PCSOR_INDEX  add datafile '+DATA' size 32767M AUTOEXTEND ON  NEXT 1G maxsize  32767M;

alter tablespace PCSOR_ADMIN  add datafile '+DATA' size 32767M AUTOEXTEND OFF;


alter tablespace CREDIT add datafile '+DATA1' size 32767M AUTOEXTEND OFF

alter tablespace ADDRESS_LOOKUP add datafile '+DATA3' size 32767M AUTOEXTEND OFF

alter tablespace PCSOR_OP add datafile '+DATA' size 32767M AUTOEXTEND OFF;

alter tablespace UC4_DATA add datafile '+DATA' size 32767M AUTOEXTEND OFF;

alter tablespace GWEXTERNAL add datafile '+DATA' size 32767M AUTOEXTEND OFF;

alter tablespace PCSOR_INDEX add datafile '+DATA' size 32767M AUTOEXTEND OFF;

alter tablespace CUST add datafile '+DATA2' size 10000M AUTOEXTEND OFF;

alter tablespace INFA_STAGE add datafile '+DATA2' size 32767M AUTOEXTEND OFF;

alter tablespace INFORMED_QUOTE add datafile '+DATA1' size 32767M AUTOEXTEND OFF;

alter tablespace BC_INDEX  add datafile '+DATA' size 32767M AUTOEXTEND OFF;

alter tablespace PCSOR_OP add datafile '+DATA' size 32767M AUTOEXTEND OFF

alter tablespace BC_OP add datafile '+DATA' size 32767M AUTOEXTEND OFF;

      ALTER TABLESPACE TEMP ADD TEMPFILE '+DATA' SIZE 32767M AUTOEXTEND OFF;

ALTER TABLESPACE AUDIT_SERVICES ADD datafile '+DATA' SIZE 32767M AUTOEXTEND OFF;

alter tablespace WEB add datafile '+DATA' size 32767M AUTOEXTEND OFF;

create tablespace web 

alter tablespace ADDRESS_LOOKUP2 add datafile '+DATA' size 32767M autoextend off;

alter tablespace UC4_DATA add datafile '+DATA' size 32767M autoextend off;


alter tablespace MGMT_TABLESPACE add datafile '+DATA_OE' size 5120M;