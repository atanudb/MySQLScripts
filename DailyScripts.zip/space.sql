set lines 160 pages 105 pause off echo off feedb on

column tablespace_name        head 'Tablespace|Name'       format 9,999,990.00
column avail_size             head 'Available|Size (MB)'   format 9,999,990.00
column alloc_size             head 'Allocated|Size (MB)'   format 999,999,990.00
column space_used             head 'Space Used (MB)'       format 9,999,990.00
column avail_space_used_pct   head 'Available|Used (%)'    format 990.0
column alloc_space_used_pct   head 'Allocated|Used (%)'    format 990.0
column avail_free_space       head 'Available|Free (MB)'   format 9,999,999.00
column alloc_free_space       head 'Allocated|Free (MB)'   format 9,999,999.00
column count_df               head 'Datafiles'             format 999

select
   a.tablespace_name,
   a.bytes_alloc/(1024*1024) avail_size,
   a.physical_bytes/(1024*1024) alloc_size,
   nvl(b.tot_used,0)/(1024*1024) space_used,
   (nvl(b.tot_used,0)/a.bytes_alloc)*100 avail_space_used_pct,
   (nvl(b.tot_used,0)/a.physical_bytes)*100 alloc_space_used_pct,
   a.bytes_alloc/(1024*1024) - nvl(b.tot_used,0)/(1024*1024)  avail_free_space,
   a.physical_bytes/(1024*1024) - nvl(b.tot_used,0)/(1024*1024)  alloc_free_space,
   count_df
from
   (select
      tablespace_name,
      sum(bytes) physical_bytes,
      sum(decode(autoextensible,'NO',bytes,'YES',maxbytes)) bytes_alloc,
      count(*) count_df
    from
      dba_data_files
    group by
      tablespace_name ) a,
   (select
      tablespace_name,
      sum(bytes) tot_used
    from
      dba_segments
    group by
      tablespace_name ) b
where
   a.tablespace_name = b.tablespace_name (+)
and
   a.tablespace_name not in
   (select distinct
       tablespace_name
    from
       dba_temp_files)
and
   a.tablespace_name not like 'UNDO%'
order by 1
/

