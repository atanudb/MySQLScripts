SET LONG 50000
set linesize 32767
set pages 40000
set trimspool on
set colsep ','
spool output
col TABLENAME format a20
col NAME format a20 WORD_WRAPPED
col DESCRIPTION format a20 WORD_WRAPPED
col STARTTIME format a20
col ENDTIME format a20
col FINGERPRINT format a20
col SQLFAILUREMSG format a15
col sqllineabove format a1000
select TABLENAME||','|| NAME||','|| DESCRIPTION||','|| NUMROWS||','|| STARTTIME||','|| ENDTIME||','|| DURATION||','|| FINGERPRINT||','|| QUERYTOIDENTIFYROWS||','|| QUERYTEXT||','|| SQLFAILUREMSG
as sqllineabove
from (
   select ROW_NUMBER() OVER (PARTITION BY dbccquery.fingerprint order by dbccquery.starttime desc) as RANK, dbccquery.tablename, dbcctype.name, dbccquery.description, dbccquery.numrows, dbccquery.starttime, dbccquery.endtime, dbccquery.duration, dbccquery.fingerprint, dbccquery.querytoidentifyrows, dbccquery.querytext, dbccquery.sqlfailuremsg
    from bc_dbconsistcheckqueryexec dbccquery
    join bctl_consistencychecktype dbcctype on dbcctype.id = dbccquery.consistencychecktype
    order by dbccquery.tablename, dbccquery.fingerprint asc
) where RANK = 1
and numrows > 0;
spool off