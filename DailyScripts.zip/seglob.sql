col rnk for 999 heading '#'
col segment_name for a35
col segment_type for a14
col lob_column for a50
col position for 999 heading 'POS'
col gb for 9,999.99
col pct_total for 999.99 head '% of Total'
set pages 9999 lines 160
break on report
compute sum of gb on report
compute sum of pct_total on report
ttitle "PCSOR_OP Segment Growth"
alter session set nls_date_format='DD-MON-YYYY HH24:MI.SS';
select  rank() over (order by bytes desc) position,
        seg.segment_name,
        CASE seg.segment_type WHEN 'LOBSEGMENT' THEN 'LOBSEG' ELSE seg.segment_type END segment_type,
        TRUNC(bytes/1024/1024/1024, 1) GB,
        ROUND(100*(bytes / SUM(bytes) OVER ()), 2) pct_total,
        CASE
                WHEN seg.segment_type IN ( 'LOBSEGMENT' , 'LOB PARTITION' )
                        THEN lobs.table_name||'.'||lobs.column_name
                        ELSE NULL
        END lob_column
from    dba_segments seg        left outer join dba_lobs lobs on (seg.segment_name = lobs.segment_name AND seg.owner = lobs.owner)
where   seg.tablespace_name='PCSOR_OP'
order by bytes desc fetch first 50 rows only
/
