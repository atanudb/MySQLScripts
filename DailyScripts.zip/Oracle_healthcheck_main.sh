#
###################
#    DEBUG
export Debug=N
#set -x
#export Debug=y
#
##################################
###    Set environment variables.   Copied from profile so script will run via crontab
###
#export SSH_AUTH_SOCK=/tmp/ssh-NQzrj28583/agent.28583
#export SSH_CLIENT=10.55.55.58 58570 22
#export SSH_CONNECTION=10.55.55.58 58570 10.64.107.204 22
#export SSH_TTY=/dev/pts/0
###################################
export date=`date "+%d-%m-%Y_%H-%M"`
export tdate=`date "+%d-%m-%Y  %H:%M"`
export run_dir="/home/oracle/Oracle_Healthcheck"
export rep_dir="${run_dir}/reports"
export par_lst=${1:-oracle_test.lst}
export conerr="/tmp/oracle_health_check_conerr_$$"
export Ohealthcheck_test=${2:-"Normal"}
if [ "${par_lst}" = "oracle_pr1.lst" ]
  then
  env="PROD"
fi
#if [ "$2" = "Jim" ]
#  then
#  export Ohealthcheck_test="YES"
#fi
#
# Read first line of server list to load title.
#
export par_file=${run_dir}/${par_lst}
exec 3<${par_file}
read  -u 3 read_rep_title
export rep_title="${read_rep_title}"
[[ $Debug = "y" ]] && echo ${read_rep_title}>/tmp/Oracle_debug_$$
[[ $Debug = "y" ]] && echo ${tdate}>>/tmp/Oracle_debug_$$

bash ${run_dir}/Oracle_healthcheck_loop.sh  > ${rep_dir}/OHC_${env:-Nonprod}_$date.lst
[[ $Debug = "y" ]] && echo "back from loop shell ">>/tmp/Oracle_debug_$$
#email main report to DBA's
echo "<h1><font face=\"Calibri\">ORACLE HEALTH CHECK     `date '+%d-%b %H:%M'`</h1>">${rep_dir}/Todays_main_rpt.html
echo "<a name=\"TheTop\"></a>" >>${rep_dir}/Todays_main_rpt.html
echo "<p><b>Report Summary</b></p>">>${rep_dir}/Todays_main_rpt.html
if [ -f $conerr  ]
  then
  cat ${conerr}>>${rep_dir}/Todays_main_rpt.html
fi
cat ${rep_dir}/OHC_${env:-Nonprod}_$date.lst|grep "WARNING"|grep "href">>${rep_dir}/Todays_main_rpt.html
cat ${rep_dir}/OHC_${env:-Nonprod}_$date.lst|grep "ORACLE HEALTH CHECK "|grep -v WARN|grep "href">>${rep_dir}/Todays_main_rpt.html
echo "<br>">>${rep_dir}/Todays_main_rpt.html
echo "<br>">>${rep_dir}/Todays_main_rpt.html
echo "<br>">>${rep_dir}/Todays_main_rpt.html
echo "<br>">>${rep_dir}/Todays_main_rpt.html
echo "<p><b>Report Detail</b></p>">>${rep_dir}/Todays_main_rpt.html

awk '!/<h2><a href/' ${rep_dir}/OHC_${env:-Nonprod}_$date.lst >>${rep_dir}/Todays_main_rpt.html
bash ${run_dir}/Omail.sh
