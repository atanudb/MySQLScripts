------------------------------------
To check list of Invalid objects
------------------------------------
COLUMN object_name FORMAT A30
COLUMN Owner format A30
SELECT owner,
       object_type,
       object_name,
       status
FROM   dba_objects
WHERE  status = 'INVALID'
ORDER BY owner, object_type, object_name;

-------------------------------------
Remediation of Invalid objects
-------------------------------------
sqlplus "/ AS SYSDBA"
SQL> @Oracle_home/rdbms/admin/utlrp.sql

Replace Oracle_home with actual path. (example - /u01/app/oracle/product/12.1.0/db_1)

@/u01/app/oracle/product/12.1.0/db_1/rdbms/admin/utlrp.sql

@/u01/app/oracle/product/12.1.0.2/db_2/rdbms/admin/utlrp.sql

alternative path - es,
