select * from 
   (select owner,segment_name||'~'||partition_name segment_name,bytes/(1024*1024) meg from dba_segments where tablespace_name = 'SYSAUX'
   order by blocks desc) fetch first 100 rows only;

   -- Set retention period to 90 days
exec dbms_stats.alter_stats_history_retention(90);

-- Display retention period:
select dbms_stats.get_stats_history_retention from dual;

-- Manually purge after x days and before
exec dbms_stats_purge_stats(SYSDATE-30);


