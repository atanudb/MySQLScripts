ASM Disk - Can be run as SYSDBA when connected to the database instance or SYSASM when connected to the ASM instance
********

SET LINESIZE  145
SET PAGESIZE  9999
SET VERIFY    off
COLUMN group_name             FORMAT a20           HEAD 'Disk Group|Name'
COLUMN sector_size            FORMAT 99,999        HEAD 'Sector|Size'
COLUMN block_size             FORMAT 99,999        HEAD 'Block|Size'
COLUMN allocation_unit_size   FORMAT 999,999,999   HEAD 'Allocation|Unit Size'
COLUMN state                  FORMAT a11           HEAD 'State'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

break on report on disk_group_name skip 1
compute sum label "Grand Total: " of total_mb used_mb on report

SELECT
    name                                     group_name
  , sector_size                              sector_size
  , block_size                               block_size
  , allocation_unit_size                     allocation_unit_size
  , state                                    state
  , type                                     type
  , total_mb                                 total_mb
  , (total_mb - free_mb)                     used_mb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v$asm_diskgroup
ORDER BY
    name
/


Tablespace
**********

SET PAGES 10000 LINES 132 TRIMS ON 
DEFINE threshold = 0.90
COL tablespace_name FORMAT A30 
COL total_mb FORMAT 9,999,990 
COL free_mb FORMAT 9,999,990 
COL max_mb FORMAT 9,999,990 
COL pct_used FORMAT 990.00 
COL max_pct_used FORMAT 990.00 
COL add_mb_to_threshold FORMAT 9,999,990 
SELECT t.tablespace_name, t.total_mb, f.free_mb, (t.total_mb - f.free_mb)*100/t.total_mb pct_used, GREATEST(t.max_mb, t.total_mb) max_mb, (t.total_mb - f.free_mb)*100/GREATEST(t.max_mb, t.total_mb) max_pct_used, 
CASE 
WHEN (t.total_mb - f.free_mb)/&threshold > t.total_mb THEN (t.total_mb - f.free_mb)/&threshold - t.total_mb
ELSE NULL 
END add_mb_to_threshold 
FROM (SELECT tablespace_name, SUM(bytes)/1024/1024 total_mb, SUM(CASE WHEN autoextensible = 'YES' THEN maxbytes ELSE bytes END)/1024/1024 max_mb FROM dba_data_files 
GROUP BY tablespace_name 
UNION ALL 
SELECT tablespace_name, SUM(bytes)/1024/1024 total_mb, SUM(CASE WHEN autoextensible = 'YES' THEN maxbytes ELSE bytes END)/1024/1024 max_mb FROM dba_temp_files GROUP BY tablespace_name) t 
LEFT OUTER JOIN (SELECT tablespace_name, SUM(bytes)/1024/1024 free_mb FROM dba_free_space GROUP BY tablespace_name UNION ALL SELECT tablespace_name, bytes_free/1024/1024 free_mb FROM v$temp_space_header) f 
ON t.tablespace_name = f.tablespace_name 
ORDER BY 6 DESC; 
COL FILE_NAME for a60 
select file_name, bytes/(1024*1024),file_id from dba_data_files where tablespace_name='&Tablespace_Name'; 


File location
*************

SET PAGES 10000 LINES 200 TRIMS ON

COL today NEW_VALUE today
SELECT TO_CHAR(sysdate, 'yyyymmddhh24miss') today FROM DUAL;

COL dbname NEW_VALUE dbname
SELECT name dbname FROM v$database;

COL dir_name NOPRINT
COL file_name FORMAT A80
COL file_type FORMAT A7
COL mbytes FORMAT 999,999,990
COL maxmbytes FORMAT 999,999,990

BREAK ON dir_name SKIP 1 ON report
COMPUTE SUM OF mbytes maxmbytes ON dir_name report

SPOOL dbfiles_&dbname._&today

SELECT SUBSTR(file_name, 1, INSTR(file_name, '/', -1) - 1) dir_name
        , file_name, file_type, bytes/1024/1024 mbytes, maxbytes/1024/1024 maxmbytes
FROM (
        SELECT 'DATA' file_type, file_name, bytes, GREATEST(bytes, maxbytes) maxbytes
        FROM dba_data_files
        UNION ALL
        SELECT 'TEMP', file_name, bytes, GREATEST(bytes, maxbytes)
        FROM dba_temp_files
        UNION ALL
        SELECT 'CONTROL', name, block_size * file_size_blks, block_size * file_size_blks
        FROM v$controlfile
        UNION ALL
        SELECT 'LOGFILE', lf.member, bytes, bytes
        FROM v$log l
        JOIN v$logfile lf
        ON l.group# = lf.group#
)
ORDER BY 1;

SPOOL OFF


