Check Largest Folders / Files (run as root)
---------------------------------------------------------------------
du -skh * | sort -rh | head -100


/* -  du -Shx / | sort -rh | head -10 */
Find large files created/modified in the last 24 hours
-------------------------------------------------------------------
find . -type f -mtime -1 -printf "%p %s\n" | sort -k2nr | head -5




FIND a list of files modfied in last 1 day and delete these files-
---------------------------------------------------------------------
nohup find ./ -name "*.aud" -mtime +1 -exec rm -f {} \; &

Check if files are being deleted after earlier command is run
--------------------------------------------------------------------
ls -l | wc -l




Check if Oracle database is up

SELECT INSTANCE_NAME, STATUS, DATABASE_STATUS FROM V$INSTANCE;

Add OT alias

sudo vi ~/.bashrc
alias ot='cat /etc/oratab'
reload .bashrc