break on report
compute sum of mb on report
col segment_name for a30
col segment_type for a25
col partition_name for a25
col mb for 9,999,999
set verify off pages 9999 lines 140
select segment_name, segment_type, partition_name, bytes/1024/1024 MB from dba_segments where segment_name=UPPER('&&2') and owner=upper('&&1')
union
select segment_name, segment_type, partition_name, bytes/1024/1024 MB from dba_segments
where segment_name in (select segment_name from dba_lobs where table_name=UPPER('&&2')) and owner=upper('&&1')
union
select segment_name, segment_type, partition_name, bytes/1024/1024 MB from dba_segments
where segment_name in (select index_name from dba_indexes where table_name=UPPER('&&2')) and owner=upper('&&1')
/
set verify on
clear breaks

undef 1 2

