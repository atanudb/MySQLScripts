#!/bin/bash
set -x
case "${Ohealthcheck_test}" in

Jim)
export MAILTO="james.rogers6@admiralgroup.co.uk"
;;

Paul)
export MAILTO="stuart.rees18@admiralgroup.co.uk"
;;

Stu)
export MAILTO="stuart.wilkes@admiralgroup.co.uk"
;;

Test)
export MAILTO="james.rogers6@admiralgroup.co.uk"
;;

PerfTest)
#export MAILTO="james.rogers6@admiralgroup.co.uk,Umear.MUSTAFA@admiralgroup.co.uk"
export MAILTO="james.rogers6@admiralgroup.co.uk,ITPerformanceTestTeam@admiralgroup.co.uk"
;;

*)
 export MAILTO="OracleDBAs@admiralgroup.co.uk,Richard.PEARSALL@admiralgroup.co.uk"
;;
esac

 #if [[ ${Ohealthcheck_test} = "YES" ]]
#  then
#  export MAILTO="james.rogers6@admiralgroup.co.uk"
#  export MAILTO="stuart.rees18@admiralgroup.co.uk"
#  export MAILTO="stuart.wilkes@admiralgroup.co.uk"
#  else
#  export MAILTO="OracleDBAs@admiralgroup.co.uk,Richard.PEARSALL@admiralgroup.co.uk"
#fi

#export MAILTO="OracleDBAs@admiralgroup.co.uk,Richard.PEARSALL@admiralgroup.co.uk"
#export MAILTO="james.rogers6@admiralgroup.co.uk"
#export MAILTO="james.rogers6@admiralgroup.co.uk,Richard.PEARSALL@admiralgroup.co.uk"
export CONTENT="${rep_dir}/Todays_main_rpt.html"
export SUBJECT="${rep_title}   ${tdate}"
(
 echo "Subject: $SUBJECT"
 echo "MIME-Version: 1.0"
 echo "Content-Type: text/html"
 echo "Content-Disposition: inline"
 cat $CONTENT
) | /usr/sbin/sendmail $MAILTO
