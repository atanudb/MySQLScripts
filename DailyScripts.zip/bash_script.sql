bash_profile - Copy to bash profile for history settings in sqlplus.

# .bash_profile
# Get the aliases and functions
if [ -f ~/.bashrc ]; then
. ~/.bashrc
fi
# Set the Oracle shell environment
umask 022
export TMP=/tmp;
export TMPDIR=;

PATH=/usr/lib64/qt-3.3/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin:/sbin:/root/bin
export PATH
export ORACLE_BASE=/u01/app/oracle
export ORACLE_SW=/home/oracle/rdbms/12c/linux/x86_64
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/db_1
export GRID_HOME=/u02/app/oracle/product/12.1.0.2/grid
export LD_LIBRARY_PATH=/lib/lib:/usr/lib
export PATH=/usr/lib64/qt-3.3/bin:/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin:/bin
export CLASSPATH=/JRE:/jlib:/rdbms/jlib;

alias template='cd /u01/app/oracle/product/11.2.0/db_1/assistants/dbca/templates'
alias sqlplus='rlwrap sqlplus'
alias rman='rlwrap rman'
alias ot='cat /etc/oratab'