Restore Points
----------------------------------

List Restore Points
-----------------------------------
select * from v$restore_point;


----------------------------------
Create restore point
----------------------------------

create restore point <restore_point_name> guarantee flashback database;


Drop restore Points
-----------------------------------
drop restore point <name>;


------------------------------------
Restore from a restore point
------------------------------------
SQL> select current_scn from v$database;
SQL> shutdown immediate;
SQL> startup mount;
SQL> select * from v$restore_point;
SQL> flashback database to restore point CLEAN_DB;
SQL> alter database open resetlogs;
SQL> select current_scn from v$database;


/*------------------------------------------------*/

Pre Upgrade Steps -

a) check size of db_recovery_file_dest_size. alter size if required.
b) check location of db_recovery_file_dest. 
c) create restore point <restorepointname> guarantee flashback database;
d) Complete level 0 RMAN backup
e) Optional - Protect spfile - SQL> create pfile='/u01/app/oracle/product/12.1.0.2/dbs/init<DBNAME>.ora' from spfile;



If Database needs to be Flashback after Upgrade -

a) shutdown immediate
b) startup mount;
c) flashback database to restore point <restorepointname>;
d) shutdown immediate
e) startup mount;
f) alter database open resetlogs;
g) check if database is operational. "select open_mode from v$database"
h) drop restore point <restorepointname>;
