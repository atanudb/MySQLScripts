ASM - Check Disk Utillisation & Add space as needed

Step 1 : 

set pages 300
set lines 300
col inst_id for 999
col dg_name for a15
col name for a20
col state for a10
col type for a10
col mount_status for a15
col header_status for a15
col DISK_NUMBER for 999
col path for a40

select d.inst_id, dg.name dg_name,  dg.state dg_state,    dg.type,d.name, d.DISK_NUMBER dsk_no, d.MOUNT_STATUS, d.HEADER_STATUS, d.MODE_STATUS,
d.STATE, d. PATH, d.FAILGROUP FROM GV$ASM_DISK d, gv$asm_diskgroup dg
where dg.group_number(+)=d.group_number and d.inst_id = dg.inst_id order by d.FAILGROUP;


 

Step 2 :

column disk_number FORMAT 999,999,999
column header_status FORMAT a20
column mode_status FORMAT a20
column path FORMAT a30
column MOUNT_STATUS FORMAT a20

select disk_number,GROUP_NUMBER, header_status, mode_status, path , MOUNT_STATUS, os_mb from v$asm_disk
order by disk_number;


 !lsblk - to check disk structure

STEP 3: 

Don't forget to login as SYSASM!

ALTER DISKGROUP data ADD DISK 'ORCL:PERF_DAT35';
or
alter diskgroup DATA add disk '/dev/oracleasm/disksdj' 
;   

ALTER DISKGROUP DATA RESIZE ALL;

Don't forget to login as SYSASM!


 

STEP 4 :

select * from v$asm_operation;


 


STEP 5: 

SET LINESIZE  145
SET PAGESIZE  9999
SET VERIFY    off
COLUMN group_name             FORMAT a20           HEAD 'Disk Group|Name'
COLUMN sector_size            FORMAT 99,999        HEAD 'Sector|Size'
COLUMN block_size             FORMAT 99,999        HEAD 'Block|Size'
COLUMN allocation_unit_size   FORMAT 999,999,999   HEAD 'Allocation|Unit Size'
COLUMN state                  FORMAT a11           HEAD 'State'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

break on report on disk_group_name skip 1
compute sum label "Grand Total: " of total_mb used_mb on report

SELECT
    name                                     group_name
  , sector_size                              sector_size
  , block_size                               block_size
  , allocation_unit_size                     allocation_unit_size
  , state                                    state
  , type                                     type
  , total_mb                                 total_mb
  , (total_mb - free_mb)                     used_mb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v$asm_diskgroup
ORDER BY
    name
/


--- Modify Datafile size
alter database Datafile <file_id> resize <new resize amount>;