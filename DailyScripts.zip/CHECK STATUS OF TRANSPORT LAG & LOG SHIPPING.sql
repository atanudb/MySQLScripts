CHECK STATUS OF TRANSPORT LAG & LOG SHIPPING

Transport Lag
----------------------------------------------------------------------------------------------------------------------------
SQL> SET LINESIZE 200
SQL> COL VALUE FOR A30
SQL> SELECT NAME,VALUE,TIME_COMPUTED,DATUM_TIME FROM V$DATAGUARD_STATS WHERE NAME LIKE '%lag';

NAME                             VALUE                          TIME_COMPUTED                  DATUM_TIME
-------------------------------- ------------------------------ ------------------------------ ------------------------------
transport lag                    +00 00:00:00                   11/18/2021 09:01:47            11/18/2021 09:01:46
apply lag                        +00 00:00:00                   11/18/2021 09:01:47            11/18/2021 09:01:46



Log Shipping
---------------------------------------------------------------------------------------------------------------------------
select SEQUENCE#, THREAD#, applied, COMPLETION_TIME from v$archived_log order by COMPLETION_TIME;