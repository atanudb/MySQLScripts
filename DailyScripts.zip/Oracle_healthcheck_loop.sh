#!/bin/bash


#servers=$(cat /var/lib/rundeck/Oracle_monitor/oracle_nonprod.lst | tr "\n" " ")

#echo "`date "+%d-%m-%Y"`"
#set -x
export HC_TimeOut=600   # 10 Minutes
export PassLife=/tmp/OraHealth_PassLife_$$

[[ $Debug = "y" ]] && echo "entering loop">>/tmp/Oracle_debug_$$
read  -u 3 -a host_name

[[ $Debug = "y" ]] && echo "first loop read " ${host_name}>>/tmp/Oracle_debug_$$
while true
do
  #Check server exists
  nc -z ${host_name[0]} 22
  if  [ $? -eq 0 ]
    then
      ssh  -o StrictHostKeyChecking=no oracle@${host_name[0]} "chage -l oracle">${PassLife}
      if  [ $? -eq 0 ]
      then
          [[ $Debug = "y" ]] && echo "in loop read " ${host_name}>>/tmp/Oracle_debug_$$
          echo ${host_name[@]}>/tmp/OracleHealthCheck.params
          scp -o StrictHostKeyChecking=no /tmp/OracleHealthCheck.params oracle@${host_name[0]}:/var/tmp/OracleHealthCheck.params
          scp -o StrictHostKeyChecking=no ${run_dir}/OracleHealthCheck.sh oracle@${host_name[0]}:/var/tmp/OracleHealthCheck.sh
          ssh -o StrictHostKeyChecking=no oracle@${host_name[0]} "chmod 744 /var/tmp/OracleHealthCheck.sh"
          #ssh -o StrictHostKeyChecking=no root@${host_name[0]} "chown oracle:oinstall /var/tmp/OracleHealthCheck.sh"
          timeout ${HC_TimeOut} ssh -o  ServerAliveInterval=60 -o StrictHostKeyChecking=no oracle@${host_name[0]} /var/tmp/OracleHealthCheck.sh
      else
         echo "<p><font face=\"Calibri\" color=\"red\">Oracle Account ERROR:    Can't connect to ${host_name[0]}  </font></p>" >>$conerr
      fi
   else
     echo "<p><font face=\"Calibri\" color=\"red\">CONNECTION ERROR:    Can't connect to ${host_name[0]}  </font></p>" >>$conerr
  fi
  read  -u 3 -a host_name
[[ $? -ne 0 ]] && break
done